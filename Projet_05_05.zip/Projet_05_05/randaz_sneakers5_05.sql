--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

-- Started on 2021-05-05 16:31:48

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 3069 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 215 (class 1255 OID 16915)
-- Name: is_admin(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_admin(text, text) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
	declare f_login alias for $1;
	declare f_password alias for $2;
	declare id integer;
	declare retour integer;	
begin
	select into id id_admin from rdz_admin where login = f_login and password = f_password;
	if not found
	then
		retour = 0;
	else
		retour = 1;
	end if;
	return retour;
end;
$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 209 (class 1259 OID 16906)
-- Name: rdz_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_admin (
    id_admin integer NOT NULL,
    login text,
    password text
);


--
-- TOC entry 208 (class 1259 OID 16904)
-- Name: rdz_admin_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_admin_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3070 (class 0 OID 0)
-- Dependencies: 208
-- Name: rdz_admin_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_admin_id_admin_seq OWNED BY public.rdz_admin.id_admin;


--
-- TOC entry 211 (class 1259 OID 16918)
-- Name: rdz_cat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_cat (
    id_cat integer NOT NULL,
    nom_cat text NOT NULL,
    image text NOT NULL
);


--
-- TOC entry 210 (class 1259 OID 16916)
-- Name: rdz_cat_id_cat_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_cat_id_cat_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3071 (class 0 OID 0)
-- Dependencies: 210
-- Name: rdz_cat_id_cat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_cat_id_cat_seq OWNED BY public.rdz_cat.id_cat;


--
-- TOC entry 207 (class 1259 OID 16860)
-- Name: rdz_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_client (
    id_client integer NOT NULL,
    nom_client text NOT NULL,
    prenom_client text NOT NULL,
    adresse text NOT NULL,
    numero text NOT NULL,
    telephone text NOT NULL,
    email text NOT NULL
);


--
-- TOC entry 206 (class 1259 OID 16858)
-- Name: rdz_client_id_client_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_client_id_client_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3072 (class 0 OID 0)
-- Dependencies: 206
-- Name: rdz_client_id_client_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_client_id_client_seq OWNED BY public.rdz_client.id_client;


--
-- TOC entry 201 (class 1259 OID 16832)
-- Name: rdz_commande; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_commande (
    id_commande integer NOT NULL,
    id_client integer NOT NULL,
    date date NOT NULL,
    prix real NOT NULL
);


--
-- TOC entry 200 (class 1259 OID 16830)
-- Name: rdz_commande_id_commande_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_commande_id_commande_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3073 (class 0 OID 0)
-- Dependencies: 200
-- Name: rdz_commande_id_commande_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_commande_id_commande_seq OWNED BY public.rdz_commande.id_commande;


--
-- TOC entry 203 (class 1259 OID 16840)
-- Name: rdz_panier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_panier (
    id_panier integer NOT NULL
);


--
-- TOC entry 202 (class 1259 OID 16838)
-- Name: rdz_panier_id_panier_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_panier_id_panier_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3074 (class 0 OID 0)
-- Dependencies: 202
-- Name: rdz_panier_id_panier_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_panier_id_panier_seq OWNED BY public.rdz_panier.id_panier;


--
-- TOC entry 205 (class 1259 OID 16848)
-- Name: rdz_produit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_produit (
    id_produit integer NOT NULL,
    marque text NOT NULL,
    modele text NOT NULL,
    quantite integer NOT NULL,
    prix real NOT NULL,
    image text,
    description text,
    couleur text,
    reference text,
    type_produit integer
);


--
-- TOC entry 204 (class 1259 OID 16846)
-- Name: rdz_produit_id_produit_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_produit_id_produit_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3075 (class 0 OID 0)
-- Dependencies: 204
-- Name: rdz_produit_id_produit_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_produit_id_produit_seq OWNED BY public.rdz_produit.id_produit;


--
-- TOC entry 213 (class 1259 OID 16929)
-- Name: rdz_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rdz_type (
    id_type integer NOT NULL,
    nom_type text NOT NULL
);


--
-- TOC entry 212 (class 1259 OID 16927)
-- Name: rdz_type_id_type_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rdz_type_id_type_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3076 (class 0 OID 0)
-- Dependencies: 212
-- Name: rdz_type_id_type_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rdz_type_id_type_seq OWNED BY public.rdz_type.id_type;


--
-- TOC entry 214 (class 1259 OID 16964)
-- Name: vue_produits_cat; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vue_produits_cat AS
 SELECT rdz_produit.id_produit,
    rdz_produit.type_produit,
    rdz_produit.marque,
    rdz_produit.modele,
    rdz_produit.quantite,
    rdz_produit.prix,
    rdz_produit.image,
    rdz_produit.description,
    rdz_type.id_type,
    rdz_type.nom_type,
    rdz_cat.id_cat,
    rdz_cat.nom_cat
   FROM public.rdz_type,
    public.rdz_produit,
    public.rdz_cat
  WHERE ((rdz_type.id_type = rdz_produit.type_produit) AND (rdz_produit.type_produit = rdz_cat.id_cat));


--
-- TOC entry 2900 (class 2604 OID 16909)
-- Name: rdz_admin id_admin; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_admin ALTER COLUMN id_admin SET DEFAULT nextval('public.rdz_admin_id_admin_seq'::regclass);


--
-- TOC entry 2901 (class 2604 OID 16921)
-- Name: rdz_cat id_cat; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_cat ALTER COLUMN id_cat SET DEFAULT nextval('public.rdz_cat_id_cat_seq'::regclass);


--
-- TOC entry 2899 (class 2604 OID 16863)
-- Name: rdz_client id_client; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_client ALTER COLUMN id_client SET DEFAULT nextval('public.rdz_client_id_client_seq'::regclass);


--
-- TOC entry 2896 (class 2604 OID 16835)
-- Name: rdz_commande id_commande; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_commande ALTER COLUMN id_commande SET DEFAULT nextval('public.rdz_commande_id_commande_seq'::regclass);


--
-- TOC entry 2897 (class 2604 OID 16843)
-- Name: rdz_panier id_panier; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_panier ALTER COLUMN id_panier SET DEFAULT nextval('public.rdz_panier_id_panier_seq'::regclass);


--
-- TOC entry 2898 (class 2604 OID 16851)
-- Name: rdz_produit id_produit; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_produit ALTER COLUMN id_produit SET DEFAULT nextval('public.rdz_produit_id_produit_seq'::regclass);


--
-- TOC entry 2902 (class 2604 OID 16932)
-- Name: rdz_type id_type; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_type ALTER COLUMN id_type SET DEFAULT nextval('public.rdz_type_id_type_seq'::regclass);


--
-- TOC entry 3059 (class 0 OID 16906)
-- Dependencies: 209
-- Data for Name: rdz_admin; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rdz_admin (id_admin, login, password) VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3');


--
-- TOC entry 3061 (class 0 OID 16918)
-- Dependencies: 211
-- Data for Name: rdz_cat; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rdz_cat (id_cat, nom_cat, image) VALUES (2, 'Streetwear', 'cat2.png');
INSERT INTO public.rdz_cat (id_cat, nom_cat, image) VALUES (3, 'Accessoires', 'cat3.png');
INSERT INTO public.rdz_cat (id_cat, nom_cat, image) VALUES (1, 'Sneakers', 'cat1.png');


--
-- TOC entry 3057 (class 0 OID 16860)
-- Dependencies: 207
-- Data for Name: rdz_client; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rdz_client (id_client, nom_client, prenom_client, adresse, numero, telephone, email) VALUES (1, 'Randazzo', 'Flavio', 'Rue à charrettes', '71', '0470509447', 'flavio.randazzo@condorcet.be');


--
-- TOC entry 3051 (class 0 OID 16832)
-- Dependencies: 201
-- Data for Name: rdz_commande; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3053 (class 0 OID 16840)
-- Dependencies: 203
-- Data for Name: rdz_panier; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3055 (class 0 OID 16848)
-- Dependencies: 205
-- Data for Name: rdz_produit; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (11, 'Supreme', 'Camp-cap', 100, 50, 'cap.png', 'On retrouve un strap de serrage à l arrière ainsi qu’un box logo sur le devant de la casquette qui plaît tant aux fans de Supreme
Les casquettes sont déclinées en plusieurs couleurs et te permettent de les matcher avec tes sneakers favorites', 'Multi', 'A11', 3);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (12, 'Nike', 'Air Max 97', 100, 180, 'water.png', 'Dessinée par Sean Wotherspoon, le fondateur du magasin Round Two à Los Angeles et grand gagnant du concours Nike Air Max en 2017, cette sneaker est sans conteste l’un des modèles les plus attendus de l’année 2018.

Constituée d’un upper d’Air Max 97 en velours multicolore et d’une semelle Air Max 1, la Nike Air Max 1/97 Sean Wotherspoon est d’une originalité hors paire. Le look retro de cette sneaker provient directement des inspirations de Sean et de son affection pour le vintage et les sneakers des années 90.

Son attention pour les détails, c’est aussi ce qui fait l’originalité de cette sneaker. On retrouve deux petits swoosh sur l’extérieur de la sneaker et sur chaque languette est apposé un patch avec une vague.', 'Sean', 'A12', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (9, 'Supreme', 'Sacoche', 100, 80, 'sacoche_sup.png', 'Supreme donne le coup d’envoi de sa saison avec sa collection Printemps/Eté 2021 ! Fidèle à son style, on retrouve de nombreuses références à la pop culture au travers d’un assortiment de tees, sacoches et backpack.

Le Supreme Neck Pouch (SS21) affiche un design assez simple, relevé d un logo brillant en TPU sur l avant. Il est composé de nylon ripstop recyclé resistant à l eau et présente une contenance de 1,5 L.
        
', 'Black', 'A9', 3);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (4, 'Supreme', 'Basic tee', 100, 50, 'tee_sup.png', 'Quelques jours après la sortie du Supreme Cross Box Logo Hooded Sweatshirt, la marque de New York sort la version Tee Shirt du Cross Box Logo. Reprenant les couleurs du Hoodie ce tee est une des plus grosses sorties Supreme de la saison !

Le Supreme Cross Box Logo Tee est entièrement composé de coton et se pare d un design original pour son Box Logo. Ce dernier fusionne deux branding Supreme Box Logo disposés de façon à former une croix. Supreme fait par ailleurs le choix de garder la shape oversized qui plaît tant aux fans !
        
', 'Navy blue', 'A4', 2);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (6, 'Supreme', 'Hoodie Supreme', 100, 100, 'hoodie_sup.png', 'En collaboration avec la maison Swarovski, Supremesort une collection capsule box logo inédite. James Jebbia souhaite marquer le 25ème anniversaire de son label avec cette release incluant quatre hoodies et quatre t-shirts, d’une qualité supérieure.

Comme toutes les pièces de la collection, cette version black du Hooded Sweatshirt Supreme Swarovskiest confectionnée entièrement à la main à New-York. Le classique box logo est revisité selon le savoir-faire de la maison joaillère. En effet, le logo de la marque américaine est composé entièrement de cristaux Swarovski. Plus de 1201 cristaux sont utilisés pour chaque sweatshirt. Une collection capsule unique d’une qualité exceptionnelle.
        
', 'Black', 'A6', 2);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (3, 'New balance', '327 Casablanca', 100, 160, 'nb327_casa.png', 'Après l énorme succès de la première collaboration, New Balance et Casablanca sont de retour pour cette rentrée 2020. Le duo nous propose deux nouveaux coloris de New Balance 327.

La New Balance 327 Casablanca Black Logo se pare d une silhouette mélangeant des empiècements de mesh et de suède. On retrouve le branding traditionnel de New Balance avec le N noir sur le coté de la paire. Le nom du modèle est brodé sur le talon. Une outsole noir vient contraster la silhouette.

Un modèle très demandé et un coloris facile à porter cette New Balance est une des plus belles sorties de cette rentrée 2020.
        
', 'Black', 'A3', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (2, 'Yeezy', '700 V2', 100, 200, 'yeezy700_cream.png', 'Plus de 2 ans après la première version 700 V2, Yeezy relance la silhouette avec un coloris proche de l édition OG. Cette nouvelle version Cream reprend les teintes de la Static pour le plus grand plaisir des fans du modèle !

La Adidas Yeezy 700 V2 Cream se pare d’un upper habillé d une toile maillée grise et d une finition en cuir beige. L emblématique logo 3 bandes d Adidas est présent sur le quarter-panel, fait en matière réfléchissante. Le design se termine sur une semelle équipée de la technologie Boost pour un amorti parfait.

Cette version alternative à la silhouette OG est sans aucun doute l une des plus belles sorties Yeezy de ce début d année ! 

', 'Cream', 'A2', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (7, 'Supreme', 'Bag Supreme', 100, 100, 'bag_sup.png', 'La collaboration tant attendue entre Supreme et The North Face est de retour avec un nouvel assortiment composé de pièces grand froid tels que des doudounes, des polaires à capuches et des parkas. Des accessoires complètent l ensemble avec le même design reprenant l emblématique "S" logo qui compose la ligne directrice de la nouvelle collection FW20.

Le Supreme The North Face S Logo Expedition Backpack est composé d une combinaison de fils cordura en nylon 630D avec du poly boot 1200D permettant au sac d être complètement wateproof mais qui offre également une grande durabilité et une resistance accrue. Ses multiples poches quand à elles, rendent le sac plus fonctionnel que jamais pendant que différents éléments de branding TNF et Supreme et le "S" logo apparent sur la face principale apportent du détail au design fonctionnel du sac.
        
', 'Black', 'A7', 3);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (8, 'Off White', 'Valise', 200, 100, 'val_offwhite.png', 'Après plusieurs la collaboration plébiscitée avec la marque de bagagerie Rimowa, pour les "See Through Cases", Off-White sort sa propre bagagerie. Avec une collection signée Virgil Abloh, la marque italienne se diversifie.

Cette valise Off-White Case Black Quote se veut sobre dans sa conception. Avec son armature 100% polycarbonate noire et son système trolley gris, cette pièce fait le choix de la simplicité et de la légèreté. Le branding Off-White est présent en ton sur ton sur le devant, le trolley et la poignée du bagage. Un système de fermeture à code est installé pour garantir une sécurisation efficace. L’inscription « For Travel » sur le ventre de la valise apporte son caractère au design de cette pièce.

Idéal pour partir en vacances, ce bagage Off-White permet de soigner son style, jusque dans les moindres détails !
        
', 'Black', 'A8', 3);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (13, 'Jordan', 'Air Jordan 1', 100, 160, 'carousel1.png', 'Silhouette la plus populaire de la Jordan Brand, la Air Jordan 1 sort dans une édition hommage inédit. La marque au jumpman fait une rétrospective sur son histoire et celle de son créateur : Michael Jordan.

La Air Jordan 1 Retro High Homage to Home adopte un visuel unique avec une base composé de deux design différents. La partie extérieure est une réplique de la Air Jordan « Banned » et l intérieur reprend le style de la mythique AJ1 « Chicago ». Le tout habillé de rouge, de blanc et de noir évoquant la carrière de « his Airness » chez les Chicago Bulls.

Le tout vient se poser sur une semelle blanche AIR sous laquelle se trouve son outsole rouge.', 'Multi', 'A13', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (5, 'Nike', 'Hoodie travis', 100, 100, 'hoodie_travis.png', 'Sorti parallèlement à son succès planétaire "Highest In The Room" et également disponible dans un coloris Gold, ce hoodie fait s entremêler les univers respectifs de Cactus Jack, Nike et Jordan.

Le Travis Scott Jordan Cactus Jack Highest Hoodie Olive arbore un look kaki avec une coupe oversized. Comme sur la version Gold, on retrouve le logo NIKE AIR vert clair retourné sur l avant tandis que l arrière mélange le logo rouge de Jordan avec celui du label de l artiste de Houston.

A l instar de sa collaboration avec Jordan autour de la Air Jordan 6, Travis Scott voit les choses en grand et surpasse toujours les attentes du public !
        
', 'Travis', 'A5', 2);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (10, 'Jordan', 'Air Jordan 6', 100, 250, 'aj6.png', 'Teasée depuis plusieurs mois au travers de différents samples sur les réseaux sociaux, cette nouvelle Air Jordan 6 en collaboration avec le rappeur Travis Scott sera accompagnée d une capsule de merchandising.

La Air Jordan 6 Retro Travis Scott British Khaki se pare d une empeigne en daim premium de couleur kaki, rehaussée par des rappels de rouge Infrared et blanc cassé sur les brandings ou la semelle. On retrouve une poche au niveau du col, une outsole icy ainsi qu un branding Jumpman sur la languette.

Après une édition Medium Olive très réussie, Jordan et le rappeur d Houston continuent leur ascension, confirmée par les rumeurs d une triple collaboration avec le label Fragment !
', 'Beige', 'A10', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (1, 'Jordan', 'Jordan 1', 100, 180, 'jordan1_travis.png', 'La Air Jordan 1 Travis Scott « Cactus Jack » est le fruit de l’une des collaborations les plus attendues de cette année. Partenariat ayant déjà fait ses preuves, Travis Scott et Nike s’associent pour créer une édition inédite de la silhouette la plus populaire du monde.

Cette version de la Air Jordan 1 se compose d’empiècements marrons sur une empeigne en cuir box blanc. Le Swoosh noir inversé tombant sur la semelle, en décalage avec celui sur le coté intérieur, donne un caractère unique au design de la paire. On retrouve le logo « Cactus Jack » sur la languette et d’autres finitions comprenant une poche secrète dans la doublure de la paire et des smileys sur le talon.

Révélée officiellement au public à l’occasion de la cérémonie des Grammys, cette nouvelle paire signée La Flame ne manquera pas de créer l’événement chez les amateurs de sneakers et les fans de la star américaine !

', 'Travis', 'A1', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (14, 'Jordan', 'Hyper Royal', 100, 160, 'hyperroyal.png', 'La Jordan Brand n a pas finit de régaler les fans de la silhouette numéro 1. Après le succès de la version University Blue, la firme américaine dévoile un second coloris à dominante bleue.

La Air Jordan 1 Retro High OG Hyper Royal est pourvue d une base en cuir blanc surmontée d’empiècements en suède bleu qui font tout le charme de la paire. À cela s ajoutent des touches de gris au niveau des Swoosh et de la cheville. Une outsole grise fait le rappel de couleur tandis que la midsole opte pour du blanc. 

Le jeu de matières donne une touche premium et le color-block pastel fait de cette Air Jordan 1 Retro High OG une paire plus qu attendue pour les beaux jours.
', 'Bleu', 'A14', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (15, 'Adidas', 'NMD Pharrel', 100, 220, 'nmd.png', 'Adidas et l’artiste Pharrell Williams sont de retour avec un nouveau coloris monochrome de l’incontournable Human Race.

La Adidas NMD Hu Pharrell Aqua Blue se pare d un look quasi monochrome et affiche une tige en Primeknit turquoise. On retrouve ensuite d’autres éléments ton-sur-ton comme la cage latérale en TPE et le renfort arrière en cuir, des lacets de randonnée bicolores, ainsi qu’une doublure intérieure noire. Le design du serial hitmaker est finalisé par une semelle Boost turquoise ou encore par une broderie blanche en Tamil sur la toebox.

Un chausson au confort parfait, une collaboration entre deux grands noms, la paire risque de vite devenir un must-have pour cet été !', 'Bleu', 'A15', 1);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (17, 'Jordan', 'Tee-shirt', 100, 50, 'jordantee.png', 'Le nouveau coloris de la Air Jordan 6 Travis Scott se voit accompagnée de plusieurs pièces de textile pour un matching parfait!

Le Jordan T-Shirt Travis Scott Cactus Jack  se compose dune base en coton beige. On retrouve le logo de la Jordan Brand mixé au logo Nike Air à lavant. Le logo Cactus Jack et un cactus patché sont présents à larrière.

Trouve le meilleur ensemble pour matcher ta plus belle paire de Jordan Travis ou tout simplement ta paire préférée !', 'Sable', 'A17', 2);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (18, 'Lacoste', 'Bonnet x Supreme', 100, 30, 'blacoste.png', 'La collaboration tant attendue entre Supreme et Lacoste est de retour pour la saison Automne/hiver 2019. Le géant américain et la marque du joueur de tennis français nous proposent une gamme d’habits et d’accessoires complète et très colorée !

Dans cette nouvelle collection, on peut retrouver des hoodies, des shorts, des sacoches, des bonnets et des casquettes. Chacune des pièces se décline en plusieurs couleurs. Le branding des deux enseignes est présent sur chaque modèle.

Avec un matching des pièces, la collaboration propose des outfits complets pour la rentrée ! Tous ces items sortis en quantité très limitée sont déjà disponibles sur Wethenew ! Date de sortie : Septembre 2019
', 'Multi', 'A18', 3);
INSERT INTO public.rdz_produit (id_produit, marque, modele, quantite, prix, image, description, couleur, reference, type_produit) VALUES (16, 'Nike', 'Dunk Brazil', 100, 100, 'dbrazil.png', 'Après une série de belles sorties de Dunk Low à l’instar de la Kentucky ou encore la Syracuse, la marque au Swoosh revient avec une édition aux couleurs du Brésil !

La Nike Dunk Low SP Brazil présente un look bicolore avec des dominantes de vert et de jaune, qui ne sont pas sans rappeler les couleurs du Brésil. On note que l’empeigne est en cuir jaune, rehaussée par des empiècements en cuir vert eux-même accordés à l’outsole. Des touches de blancs présentes au niveau des lacets et de la midsole viennent contraster la création.

Grâce à cette nouvelle édition venant s’ajouter à la gamme des Dunk Low, les amateurs de sneakers auront une multitude de choix pour constituer les meilleurs looks estivaux.
', 'Brésil', 'A16', 1);


--
-- TOC entry 3063 (class 0 OID 16929)
-- Dependencies: 213
-- Data for Name: rdz_type; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rdz_type (id_type, nom_type) VALUES (2, 'Streetwear');
INSERT INTO public.rdz_type (id_type, nom_type) VALUES (1, 'Sneakers');
INSERT INTO public.rdz_type (id_type, nom_type) VALUES (3, 'Accessoires');


--
-- TOC entry 3077 (class 0 OID 0)
-- Dependencies: 208
-- Name: rdz_admin_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_admin_id_admin_seq', 1, true);


--
-- TOC entry 3078 (class 0 OID 0)
-- Dependencies: 210
-- Name: rdz_cat_id_cat_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_cat_id_cat_seq', 1, false);


--
-- TOC entry 3079 (class 0 OID 0)
-- Dependencies: 206
-- Name: rdz_client_id_client_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_client_id_client_seq', 1, false);


--
-- TOC entry 3080 (class 0 OID 0)
-- Dependencies: 200
-- Name: rdz_commande_id_commande_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_commande_id_commande_seq', 1, false);


--
-- TOC entry 3081 (class 0 OID 0)
-- Dependencies: 202
-- Name: rdz_panier_id_panier_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_panier_id_panier_seq', 1, false);


--
-- TOC entry 3082 (class 0 OID 0)
-- Dependencies: 204
-- Name: rdz_produit_id_produit_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_produit_id_produit_seq', 1, false);


--
-- TOC entry 3083 (class 0 OID 0)
-- Dependencies: 212
-- Name: rdz_type_id_type_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rdz_type_id_type_seq', 1, false);


--
-- TOC entry 2914 (class 2606 OID 16914)
-- Name: rdz_admin rdz_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_admin
    ADD CONSTRAINT rdz_admin_pkey PRIMARY KEY (id_admin);


--
-- TOC entry 2916 (class 2606 OID 16926)
-- Name: rdz_cat rdz_cat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_cat
    ADD CONSTRAINT rdz_cat_pkey PRIMARY KEY (id_cat);


--
-- TOC entry 2912 (class 2606 OID 16868)
-- Name: rdz_client rdz_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_client
    ADD CONSTRAINT rdz_client_pkey PRIMARY KEY (id_client);


--
-- TOC entry 2904 (class 2606 OID 16837)
-- Name: rdz_commande rdz_commande_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_commande
    ADD CONSTRAINT rdz_commande_pkey PRIMARY KEY (id_commande);


--
-- TOC entry 2906 (class 2606 OID 16845)
-- Name: rdz_panier rdz_panier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_panier
    ADD CONSTRAINT rdz_panier_pkey PRIMARY KEY (id_panier);


--
-- TOC entry 2909 (class 2606 OID 16856)
-- Name: rdz_produit rdz_produit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_produit
    ADD CONSTRAINT rdz_produit_pkey PRIMARY KEY (id_produit);


--
-- TOC entry 2918 (class 2606 OID 16937)
-- Name: rdz_type rdz_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdz_type
    ADD CONSTRAINT rdz_type_pkey PRIMARY KEY (id_type);


--
-- TOC entry 2910 (class 1259 OID 16869)
-- Name: rdz_client_id_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rdz_client_id_client_idx ON public.rdz_client USING btree (id_client);


--
-- TOC entry 2907 (class 1259 OID 16857)
-- Name: rdz_produit_id_produit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rdz_produit_id_produit_idx ON public.rdz_produit USING btree (id_produit);


-- Completed on 2021-05-05 16:31:49

--
-- PostgreSQL database dump complete
--

