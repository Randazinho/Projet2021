<?php
session_destroy();
?>
<meta http-equiv="refresh": content="2;URL=../index_.php">
