<h2>Accueil Admin</h2>

<?php
    if (isset($_POST['submit'])) {
        extract($_POST,EXTR_OVERWRITE);

        $ad = new AdminBD($cnx);
        $admin = $ad->getAdmin($login,$password);
        if($admin){
            $_SESSION['admin']=1;
            print "OK";
        }else{
            $message =  "Identifiants incorrects";
        }
    }
?>

<p class=""><?php
    if(isset($message)){
        print $message;
    }
    ?></p>

<form action="<?php print $_SERVER['PHP_SELF'];?>" method="post">
    <div class="mb-3">
        <label for="login" class="form-label">Login</label>
        <input type="login" class="form-control" id="login" aria-describedby="" name="login">
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password">
    </div>
    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>