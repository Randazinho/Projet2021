<?php
include ('./lib/php/verifier_connexion.php');

if(isset($_SESSION['admin'])){
    print "<br/>Bienvenue dans la gestion des produits";
}


