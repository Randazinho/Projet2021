<h2>Jquery</h2>

<?php
$prod = new ProduitBD($cnx);
$liste = $prod->getAllProduit();
$nbr = count($liste);
?>

<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="get">
    <label for="id">Identifiant: </label>
    <input type="text" id="id" name="id">

    &nbsp;&nbsp;
    <select name="choix_produit" id="choix_produit">
        <option value="">Choisissez</option>
        <?php
        for($i=0; $i<$nbr;$i++){
            ?>
            <option value="<?php print $liste[$i]->id_produit;?>">
                <?php print $liste[$i]->nom_produit;?>
            </option>
            <?php
        }
        ?>
    </select>
    <input type="submit" name="submit_id" value="Chercher" id="submit_id">
</form>

<div class="card-group">
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title"></h5>
            <div id="id_produit"></div>
            <div id="image_produit"></div>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title"></h5>
            <div id="id_produit"></div>
            <div id="image_produit"></div>
        </div>
    </div>
</div>


<p>&nbsp;</p>
<p>&nbsp;</p>


<h2>Wikipédia</h2>

<div id="bordure">
   <section>
       <p>
           Le nom « sneakers » a pour origine le verbe anglais « to sneak » signifiant « se déplacer furtivement » et donc silencieusement. Le nom « sneakers » faisait référence à l'origine au silence des semelles en caoutchouc au sol, contrairement aux chaussures habillées à semelle en cuir dur standard, bruyantes. Ce mot est souvent attribué à l'Américain Henry Nelson McKinney qui était un agent de publicité de Philadelphie. En 1917, il a utilisé le terme parce que la semelle en caoutchouc rendait furtif le porteur de la chaussure.

           Histoire
           L'histoire de la sneaker remonte au début du xxe siècle et est intimement liée à l'utilisation du caoutchouc4. En 1916, l'entreprise United States Rubber Company crée Keds, qui commercialise les premières chaussures dotées de semelles en caoutchouc, considérées comme les premières sneakers de l'histoire5,6,7. Remarquées pour leur confort et leur discrétion, ces chaussures marquent une rupture avec les chaussures traditionnellement utilisées pour un usage quotidien. L'année suivante, Converse crée la Chuck Taylor All Star, des chaussures de basket-ball qui seront par la suite également vendues pour un usage quotidien5.

           À partir des années 1950, la part du temps consacré au temps libre augmente considérablement. De plus, les sneakers sont de plus en plus utilisées dans les uniformes scolaires. Les ventes de sneakers augmentent de manière exponentielle, jusqu'à venir concurrencer les ventes des chaussures traditionnelles, en cuir. Durant les années 1990, les marques de sneakers s'attachent de plus en plus à l'esthétique de la chaussure et jouent du marketing pour les vendre au plus grand nombre. Les sneakers sont alors moins choisies pour leur confort que pour l'identité qu'elles façonnent pour celui qui les porte8.

           De 1970 (5 modèles) à 1998 (285 modèles) jusqu'à 2012 (3 371), le nombre de modèles de sneakers aux États-Unis a considérablement augmenté9.

           Il existe des modèles " de luxe " pouvant valoir jusqu'à 15 000 dollars10.

           La sneaker dans la culture populaire
           Véritable phénomène de société, la sneaker est devenu un sujet de manifestations diverses : expositions, conventions de collectionneurs, sujet artistique...

           En 2020, la plus grande exposition de sneakers en Europe a ouvert au Musée des Arts Décoratifs et du Design à Bordeaux le vendredi 19 juin 2020. L’expo Playground fait un bond en arrière et retrace l’histoire des baskets depuis le xxe siècle11,12.
       </p>
   </section>
</div>

<div id="contenu2">

</div>

