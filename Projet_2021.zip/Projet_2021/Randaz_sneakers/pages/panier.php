<h2>Mon panier</h2>
<?php
?>
<div>
    <a href="pages/print_produit.php" target="_blank"> <input type="button" value="Imprimer la facture"> </a>
</div>

