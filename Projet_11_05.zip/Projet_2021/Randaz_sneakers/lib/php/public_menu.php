<div class="card-header">
</div>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="index_.php?page=accueil.php">
        <img src="./admin/images/logo.jpg" width="30%" height="30%" class="d-inline-block align-top" alt="logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="index_.php?page=accueil.php">Accueil <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index_.php?page=boutique.php">Boutique</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin/index_.php?page=accueil_admin.php">Menu Admin</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index_.php?page=panier.php">Mon Panier</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index_.php?page=contact.php">Nous contacter..</a>
            </li>
        <?php
        if (!isset($_SESSION['client'])) {

        } else { ?>
            <li class="nav-item">
                <a class="nav-link" href="index_.php?page=disconnectcli.php">Se déconnecter</a>
            </li> <?php
        }
        ?>
    </ul>
</nav>
<div class="card-header">
</div>
