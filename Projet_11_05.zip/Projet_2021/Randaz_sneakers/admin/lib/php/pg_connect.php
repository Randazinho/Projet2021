<?php
//.gitignore
$dsn = 'pgsql:host=localhost;dbname=Randaz;port=5432';
$user = 'Boulangerie';
$password = 'Boulangerie';