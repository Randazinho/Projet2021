
create or replace view vue_produits_cat as select
rdz_produit.id_produit,rdz_produit.type_produit,rdz_produit.marque,rdz_produit.modele, rdz_produit.quantite,rdz_produit.prix,rdz_produit.image,rdz_produit.description,
rdz_type.id_type, rdz_type.nom_type, rdz_cat.id_cat, rdz_cat.nom_cat
from rdz_type, rdz_produit, rdz_cat
where rdz_type.id_type = rdz_produit.type_produit
and rdz_produit.type_produit = rdz_cat.id_cat;




