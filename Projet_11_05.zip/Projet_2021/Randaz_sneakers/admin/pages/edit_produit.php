<?php include ('lib/php/verifier_connexion.php'); ?>

<h2>Editer / ajouter un produit</h2>
<?php
$produit = new ProduitBD($cnx);
if(isset($_GET['editer_ajouter'])){
    extract($_GET,EXTR_OVERWRITE);
    if($_GET['action']=="editer"){
        ?><pre><?php     //var_dump($_GET);     ?></pre><?php
        if(!empty($reference) && !empty($modele) && !empty($marque) && !empty($description) && !empty($prix) && !empty($quantite) && !empty($couleur)  && !empty($image) && !empty($type_produit)  ){

            $produit->mise_a_jourProduit($id_produit,$modele,$marque,$description,$prix,$quantite,$couleur,$image,$type_produit,$reference);
            print "Produit mis à jour ";
            echo "<br />";
        }
        else
        {
            echo "Tout les champs doivent être rempli !";
        }
    } else if($_GET['action'] == "inserer") {
        ?><pre><?php     //var_dump($_GET);     ?></pre><?php
        if(!empty($reference) && !empty($modele) && !empty($marque) && !empty($description) && !empty($prix) && !empty($quantite) && !empty($couleur)  && !empty($image) && !empty($type_produit) ){

            $produit->ajout_produit($modele,$marque,$description,$prix,$quantite,$couleur,$image,$type_produit,$reference);
            print "Produit inséré ";
            echo "<br />";
        }
        else
        {
            echo "Tout les champs doivent être rempli !";
        }
    }
}
?>

<form class="row g-3" method="get" action="<?php print $_SERVER['PHP_SELF'];?>" id="formEditAjout">

    <div class="col-md-2">
        <label for="reference" class="form-label">Référence</label>
        <input type="text" class="form-control" id="reference" name="reference">
    </div>
    <div class="col-md-6">
        <label for="modele" class="form-label">Modèle</label>
        <input type="text" class="form-control" id="modele" name="modele">
    </div>
    <div class="col-md-6">
        <label for="marque" class="form-label">Marque</label>
        <input type="text" class="form-control" id="marque" name="marque">
    </div>
    <div class="col-md-12">
        <label for="description" class="form-label">Description</label>
        <input type="text" class="form-control" id="description" name="description">
    </div>
    <div class="col-md-2">
        <label for="prix" class="form-label">Prix</label>
        <input type="number" class="form-control" id="prix" name="prix">
    </div>
    <div class="col-md-2">
        <label for="quantite" class="form-label">Stock</label>
        <input type="number" class="form-control" id="quantite"  name="quantite">
    </div>
    <div class="col-md-2">
        <label for="couleur" class="form-label">Couleur</label>
        <input type="text" class="form-control" id="couleur"  name="couleur">
    </div>
    <div class="col-md-2">
        <label for="image" class="form-label">Nom du fichier image (Ex: jordan1.png)</label>
        <input type="text" class="form-control" id="image"  name="image">
    </div>
    <div class="col-md-2">
        <label for="type_produit" class="form-label">Type de produit (1: Sneakers, 2: Vêtements, 3: Accessoires)</label>
        <input type="number" class="form-control" id="type_produit"  name="type_produit">
    </div>
    <div class="col-12">
        <input type="hidden" name="id_produit" id="id_produit">
        <input type="hidden" name="action" id="action" >
        <button type="submit" class="btn btn-primary" id="editer_ajouter" name="editer_ajouter">Nouveau ou mettre à jour</button>
    </div>
</form>