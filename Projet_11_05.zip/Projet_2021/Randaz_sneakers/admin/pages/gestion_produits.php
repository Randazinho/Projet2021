<?php
include('./lib/php/verifier_connexion.php');
$prod = new ProduitBD($cnx);
$liste = $prod->getAllProduit();
$nbr = count($liste);
?>

<table class="table">
    <thead>
    <tr>
        <th scope="col">Id</th>
        <th scope="col">Modèle</th>
        <th scope="col">Marque</th>
        <th scope="col">Description</th>
        <th scope="col">Prix</th>
        <th scope="col">Stock</th>
        <th scope="col">Type</th>
    </tr>
    </thead>
    <tbody>

    <?php
    for ($i = 0; $i < $nbr; $i++) {

        ?>
        <tr>
            <th scope="row">
                <?php print $liste[$i]->id_produit; ?>
            </th>
            <td>
                <span contenteditable="true" name="modele" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->modele; ?>
                </span>
            </td>
            <td>
                <span contenteditable="true" name="marque" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->marque; ?>
                </span>
            </td>
            <td>
                <span contenteditable="true" name="description" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->description; ?>
                </span>
            </td>
            <td>
                <span contenteditable="true" name="prix" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->prix; ?>
                </span>
            </td>
            <td>
                <span contenteditable="true" name="quantite" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->quantite; ?>
                </span>
            </td>
            <td>
                <span contenteditable="true" name="type_produit" id="<?php print $liste[$i]->id_produit; ?>">
                    <?php print $liste[$i]->type_produit; ?>
                </span>
            </td>
        </tr>

        <?php
    }
    ?>

    </tbody>
</table>

