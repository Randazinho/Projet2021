
<?php
if (!isset($_SESSION['client'])) {
    ?>
    <h2>Vous devez vous connecter !</h2>
    <p>Seuls les clients peuvent accèder au panier..</p>
    <meta http-equiv = "refresh": content = "2;url=index_.php?page=connexion.php">
    <?php
} else {
?>
    <h2>Mon panier</h2>
<div>
    <a href="pages/print_produit.php" target="_blank"> <input type="button" value="Imprimer la facture"> </a>
</div>
    <?php
}
?>




