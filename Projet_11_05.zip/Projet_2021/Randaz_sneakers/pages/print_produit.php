<?php
include ('../admin/lib/php/pg_connect.php');
include ('../admin/lib/php/classes/Connexion.class.php');
include ('../admin/lib/php/classes/Produit.class.php');
include ('../admin/lib/php/classes/ProduitBD.class.php');
$cnx = Connexion::getInstance($dsn,$user,$password);
$pr = array();
$total=0;
$produit = new ProduitBD($cnx);
$liste = $produit->getAllProduit();
$nbr = count($liste);
include ('../admin/lib/php/TCPDF/tcpdf.php');
$pdf = new TCPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetTitle('Randaz Sneakers Facture');
$pdf->SetFont('times','B',15);
$pdf->SetTextColor(255,0,0);
$pdf->Cell(190,10,'Facture',1,1,'C');
$pdf->SetFont('times','',12);
$pdf->SetTextColor(0,0,0);
$x = 10;
$y = 30;
$pdf->WriteHTMLCell(190,30,$x,$y,"Liste des produits",1,1,'','','C');
for($i = 0;$i<$nbr; $i++){
    $pdf->WriteHTMLCell(190,30,$x,$y,$liste[$i]->modele,1,1,'','','C');
    $pdf->WriteHTMLCell(190,30,$x,$y,$liste[$i]->marque,1,1,'','','L');
    $pdf->WriteHTMLCell(190,30,$x,$y,$liste[$i]->prix,1,1,'','','R');
    $y=$y+10;
    $total=$total+$liste[$i]->prix;
}
$pdf->WriteHTMLCell(190,30,$x,$y,"Total : ",1,1,'','','L');
$pdf->WriteHTMLCell(190,30,$x,$y,$total,1,1,'','','C');
$pdf->WriteHTMLCell(190,30,$x,$y,"$",1,1,'','','R');
$pdf->Output();