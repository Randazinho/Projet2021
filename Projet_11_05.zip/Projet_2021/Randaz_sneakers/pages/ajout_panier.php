<?php
    $query="insert into rdz_sales_tp(id_sales,id_produit,session)
    values(1,'".$_GET['productId']."',1)";
    if(sendData($query,$cnx))
        print "Votre Ajout est enregistrée";
    else
        print "problème rencontré!!!!!  ";
    header ('location: index_.php?page=boutique.php');
?>