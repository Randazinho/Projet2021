
<div class="card text-center">
        <img src="./admin/images/1.png" size="50%" alt="logo">
        <div class="card-body">
            <h5 class="card-title">Le meilleur endroit pour tes sneakers et du streetwear </h5>
            <p class="card-text">
                Les sneakers désignent une paire de chaussures de sport détournée à un usage citadin et quotidien. Dérivées des modèles conçus pour le sport, elles sont appréciées pour leur confort et leur style. De fait, les sneakers sont aussi des accessoires de mode qui ont été employés dans le monde du hip-hop dans les années 1980 avant de devenir dans les années 2000 des marques de streetwear qui se répandent dans la culture populaire.

                Paire de Nike Air Force.
                Dans de nombreux pays, occidentaux notamment, ces chaussures sont très portées dans la rue. Les adolescents sont les principaux porteurs de la sneaker comme chaussure de tous les jours, avec les encouragements des campagnes publicitaires de grandes marques spécialisées, mais d'autres âges les portent volontiers. Pour une utilisation urbaine, les chaussures multi-sports, ou bien des modèles des années 1980–1990 réédités sont les plus portées
            </p>
            <a href="./index_.php?page=boutique.php" class="button">Tous nos produits</a>
        </div>
    </div>
    <div class="card-header">
    </div>
    <h3 class="card text-center">Nos produits par catégorie</h3>
    <div class="card-header">
    </div>
    <p>&nbsp;</p>
    <?php
    $cat = new CategorieBD($cnx);
    $liste_cat = $cat->getCategorie();
    $nbr_cat = count($liste_cat);
    ?>
    <div class="card-group">
        <?php
        for ($i = 0; $i < $nbr_cat; $i++) {
            ?>
            <div class="card">
                <img src="./admin/images/<?php print $liste_cat[$i]->image; ?>" class="card-img-top" alt="cat">
                <div class="card-body">
                    <h5 class="card-title">
                        <a class="lien" href="index_.php?page=boutique.php&id_cat=<?php print $liste_cat[$i]->id_cat; ?>">
                            <?php print $liste_cat[$i]->nom_cat; ?>
                        </a>
                    </h5>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</div>
